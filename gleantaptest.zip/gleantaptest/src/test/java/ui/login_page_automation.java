package ui;

import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class login_page_automation { 
	@Test
	public void loginTest() throws InterruptedException
	{
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver =  new ChromeDriver();
		driver.get("https://virtual.gleantap.org/login");
		driver.manage().window().maximize();
		driver.findElement(By.id("gl_username")).sendKeys("Shubham@gleantap.com");
		driver.findElement(By.id("gl_password")).sendKeys("Test1234");
		driver.findElement(By.xpath("//*[@id=\"swpm-login-form\"]/div/div[5]/input")).click();
		Thread.sleep(3000);
	    driver.findElement(By.linkText("Book a 1-on-1")).click();
		Thread.sleep(3000);	
		driver.findElement(By.linkText("John Foster")).click();
		Thread.sleep(3000);	
		driver.findElement(By.linkText("Book a Session")).click();
		Thread.sleep(3000);	
		driver.findElement(By.xpath("//*[@id=\"0505\"]/a")).click();
		Thread.sleep(3000);	
		driver.findElement(By.xpath("//*[@id=\"tab0505\"]/div/div/div[1]/div[3]")).click();
		Thread.sleep(4000);	
		driver.findElement(By.linkText("My Account")).click();
		Thread.sleep(4000);	
		driver.findElement(By.linkText("My Bookings")).click();
		Thread.sleep(7000);	
		driver.close();
	}
	
}
